#!/usr/bin/env python
# coding: utf-8

# In[1]:


#Name : Anindita Das
#Date - 15-02-2023
#Github_link : https://github.com/Anindita2019/Automatic-Ticket-Classification

pip install swifter 


# In[3]:


import json 
import numpy as np
import pandas as pd
import re, nltk, spacy, string
import en_core_web_sm
nlp = en_core_web_sm.load(disable=['parser','ner'])
import seaborn as sns
import matplotlib.pyplot as plt
from wordcloud import WordCloud, STOPWORDS
from collections import Counter
import swifter
from sklearn.feature_extraction.text import TfidfTransformer

get_ipython().run_line_magic('matplotlib', 'inline')

 


# In[ ]:


from plotly.offline import plot
import plotly.graph_objects as go
import plotly.express as px

from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from pprint import pprint

from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords

import warnings
warnings.filterwarnings('ignore')
Loading the data  


# In[5]:


#Loadind the data
# Opening JSON file 
f = open('C:/Users/easaind/OneDrive - Ericsson/Documents/complaints-2021-05-14_08_16.json') 
  


# In[6]:


data = json.load(f)
df=pd.json_normalize(data) 


# In[7]:


##DATA PREPARATION

# Inspect the dataframe to understand the given data.
df.head() 


# In[8]:


#print the column names
df.columns 


# In[9]:


#Assign new column names
df.rename(columns={'_source.complaint_what_happened':'complaints_what_happened', '_source.product':'tag'}, inplace=True) 


# In[10]:


df.columns 


# In[11]:


df = df[['complaints_what_happened', 'tag']] 


# In[12]:


df = df[df['complaints_what_happened'].astype(bool)]
df 


# In[13]:


#Prepare the text for topic modeling
#After removing blank complaints:

#Make the text lowercase
#Remove text in square brackets
#Remove punctuation
#Remove words containing numbers
#After all the cleaning operations, performed the following:

#Lemmatize the texts
#Extract the POS tags of the lemmatized text and remove all the words which have tags other than NN[tag == "NN"].

# Function to clean the text and remove all the unnecessary elements.
def clean_data(text):
    text = text.lower() # text to lowercase
    text = re.sub(r'\s\{\$\S*', '',text) # Remove text within curly braces
    text = re.sub(r'\n', '', text) # Remove line breaks
    text = re.sub(r'\(\w*\)', '', text) #remove text within braces
    text = re.sub(r'(\W\s)|(\W$)|(\W\d*)', ' ',text) # Remove punctuation
    text = re.sub(r'x+((/xx)*/\d*\s*)|x*', '',text) #Remove date
    text = re.sub(r'\d+\s', '', text) #Remove other numerical values
    text = re.sub(r' +', ' ',text) #Remove unnecessary white spaces
    return text 


# In[14]:


# Apply data cleaning to the complaints_what_happened column

df['complaints'] = df['complaints_what_happened'].apply(clean_data)
df.head() 


# In[15]:


# Function to Lemmatize the texts
def lemmatization(text):
    tokens = word_tokenize(text)
    wordnet_lemmetizer = WordNetLemmatizer()
    lemmatized = [wordnet_lemmetizer.lemmatize(token) for token in tokens]
    lemmatized_str = " ".join(lemmatized)
    return lemmatized_str 


# In[29]:


#Create a dataframe('df_clean') that will have only the complaints and the lemmatized complaints 
df_clean = pd.DataFrame({'complaints':df['complaints'], 'lemmatized':df['complaints'].apply(lemmatization)})  


# In[30]:


df_clean.head()    


# In[31]:


#Write your function to extract the POS tags 

def get_pos_tags(text):
    nn_words = []
    doc = nlp(text)
    for tok in doc:
        if(tok.tag_ == 'NN'):
            nn_words.append(tok.lemma_)
    nn_words_str = " ".join(nn_words)
    return nn_words_str

#this column should contain lemmatized text with all the words removed which have tags other than NN[tag == "NN"].
df_clean["complaint_POS_removed"] =  df_clean.swifter.apply(lambda x: get_pos_tags(x['lemmatized']), axis=1) 


# In[32]:


#The clean dataframe should now contain the raw complaint, lemmatized complaint and the complaint after removing POS tags.
df_clean 


# In[35]:


#Exploratory data analysis to get familiar with the data.
#Data visulaisation:

#Visualise the data according to the 'Complaint' character length
#Using a word cloud find the top 40 words by frequency among all the articles after processing the text
#Find the top unigrams,bigrams and trigrams by frequency among all the complaints after processing the text. ‘

# Write your code here to visualise the data according to the 'Complaint' character length
import matplotlib.pyplot as plt
plt.figure(figsize=(10,6))
doc_lens = [len(d) for d in df_clean.complaint_POS_removed]
plt.hist(doc_lens, bins = 100)
plt.ylabel('Number of Complaint')
plt.xlabel('Complaint character length')
sns.despine();  


# In[36]:


# Top 40 words frequency wise wordcloud
wordcloud = WordCloud(max_words=40, random_state=1, stopwords=set(STOPWORDS))
wordcloud.generate(str(df_clean['complaint_POS_removed']))
plt.figure(figsize=(12,12))
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show() 


# In[37]:


#Removing -PRON- from the text corpus
df_clean['Complaint_clean'] = df_clean['complaint_POS_removed'].str.replace('-PRON-', '')
df_clean 


# In[38]:


#Find the top unigrams,bigrams and trigrams by frequency among all the complaints after processing the text
def top_grams(grams):
    c_vec = CountVectorizer(stop_words=stopwords.words('english'), ngram_range=(grams,grams))
    grams = c_vec.fit_transform(df_clean['complaints'])
    count_values = grams.toarray().sum(axis=0)
    vocab = c_vec.vocabulary_
    df_ngram = pd.DataFrame(sorted([(count_values[i],k) for k,i in vocab.items()], reverse=True)
            ).rename(columns={0: 'frequency', 1:'unigram'})
    return df_ngram 


# In[39]:


df_unigram = top_grams(1)
df_unigram.head(10) 


# In[40]:


df_bigram = top_grams(2)
df_bigram.head(10) 


# In[41]:


df_trigram = top_grams(3)
df_trigram.head(10) 


# In[42]:


df_clean 


# In[43]:



#Write your code here to initialise the TfidfVectorizer 
tfidf = TfidfVectorizer(max_df=0.95, min_df=2, stop_words='english') 


# In[44]:


#Write your code here to create the Document Term Matrix by transforming the complaints column present in df_clean.
dtm = tfidf.fit_transform(df_clean['complaints']) 


# In[45]:


from sklearn.decomposition import NMF 


# In[46]:


#Manual Topic Modeling

#Load your nmf_model with the n_components i.e 5
num_topics = 5

#keep the random_state =40
nmf_model = NMF(random_state=40, n_components=num_topics) 


# In[47]:


nmf_model.fit(dtm)
len(tfidf.get_feature_names()) 


# In[48]:


#Print the Top15 words for each of the topics
words = np.array(tfidf.get_feature_names())
topic_words_df = pd.DataFrame(np.zeros((num_topics, 15)), index=[f'Topic {i + 1}' for i in range(num_topics)],
                           columns=[f'Word {i + 1}' for i in range(15)]).astype(str)

for i in range(num_topics):
    ix = nmf_model.components_[i].argsort()[::-1][:15]
    topic_words_df.iloc[i] = words[ix]

topic_words_df 


# In[49]:


#Create the best topic for each complaint in terms of integer value 0,1,2,3 & 4
topic_results = nmf_model.transform(dtm)
topic_results.argmax(axis=1) 


# In[50]:


#Assign the best topic to each of the cmplaints in Topic Column

df_clean['Topic'] = topic_results.argmax(axis=1) 


# In[51]:


df_clean.head() 


# In[52]:


# Print the first 5 Complaint for each of the Topics
First5_comp=df_clean.groupby('Topic').head(5)
First5_comp.sort_values('Topic') 


# In[53]:


# Create the dictionary of Topic names and Topics
Topic_names = {0:'Account Services', 1:'Others', 2:'Mortgage/Loan', 3:'Credit card or prepaid card', 4:'Theft/Dispute Reporting'}

# Replace Topics with Topic Names
df_clean['Topic'] = df_clean['Topic'].map(Topic_names) 


# In[54]:


df_clean 


# In[55]:


# Keep the columns"complaint_what_happened" & "Topic" only in the new dataframe --> training_data
training_data = df_clean.drop(['lemmatized', 'complaint_POS_removed', 'Complaint_clean'], axis=1) 


# In[56]:


training_data 


# In[57]:



# Write your code to get the Vector count
count_vect = CountVectorizer()
X_train_counts = count_vect.fit_transform(training_data.complaints)

# Write your code here to transform the word vector to tf-idf
tfidf_transformer = TfidfTransformer()
X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts) 


# In[58]:


#Using the required evaluation metrics judge the tried models and select the ones performing the best
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB

from sklearn.metrics import classification_report 


# In[59]:


# Split data into train and test
X_train, X_test, y_train, y_test = train_test_split(X_train_tfidf, training_data.Topic, test_size=0.2, random_state=42) 


# In[60]:


#1. Logistic Regression
# Logistic Regression
lr = LogisticRegression().fit(X_train, y_train)
predicted = lr.predict(X_test)

print(classification_report(y_true=y_test, y_pred=predicted)) 


# In[61]:


#2. Decision Tree

# Decision tree classifier
dt = DecisionTreeClassifier().fit(X_train, y_train)
predicted = dt.predict(X_test)

print(classification_report(y_pred=predicted, y_true=y_test)) 


# In[62]:


#3. Random Forest Classifier

rfc = RandomForestClassifier(max_depth=10)
rfc.fit(X_train, y_train)
predicted = rfc.predict(X_test)

print(classification_report(y_pred=predicted, y_true=y_test)) 


# In[63]:


#4. Gaussian Naive Bayes

nb = GaussianNB().fit(X_train.toarray(), y_train)
predicted = nb.predict(X_test.toarray())

print(classification_report(y_pred=predicted, y_true=y_test)) 


# In[64]:


4. Gaussian Naive Bayes

nb = GaussianNB().fit(X_train.toarray(), y_train)
predicted = nb.predict(X_test.toarr ay())

print(classification_report(y_pred=predicted, y_true=y_test)) 


# In[65]:


# Some sample complaints to infer model

df_complaints = pd.DataFrame({'complaints': ["I can not get from chase who services my mortgage, who owns it and who has original loan docs", 
                                  "The bill amount of my credit card was debited twice. Please look into the matter and resolve at the earliest.",
                                  "I want to open a salary account at your downtown branch. Please provide me the procedure.",
                                  "Yesterday, I received a fraudulent email regarding renewal of my services.",
                                  "What is the procedure to know my CIBIL score?",
                                  "I need to know the number of bank branches and their locations in the city of Dubai"]}) 


# In[66]:


df_complaints 


# In[67]:


def predict_lr(text):
    Topic_names = {0:'Account Services', 1:'Others', 2:'Mortgage/Loan', 3:'Credit card or prepaid card', 4:'Theft/Dispute Reporting'}
    X_new_counts = count_vect.transform(text)
    X_new_tfidf = tfidf_transformer.transform(X_new_counts)
    predicted = lr.predict(X_new_tfidf)
    return Topic_names[predicted[0]] 


# In[68]:


df_complaints['tag'] = df_complaints['complaints'].apply(lambda x: predict_lr([x]))
df_complaints 


# In[ ]:


#Conclusion
#As expected 5 topics were indetified namely:

#Account Services
#Others
#Mortgage/Loan
#Credit card or prepaid card
#Theft/Dispute Reporting
#Tried 4 models on the data with accuracies as follows:

#| Model | Accuracy | | ----------- | ----------- | | Logistic Regression | 0.95 | | Decision Tree | 0.77 | | Random Forest | 0.74 | | Naive Bayes | 0.36 |

